public class Main {
    public static void main(String[] args) {
        suma(5,10,22);
        Coche miCoche=new Coche();
        miCoche.agregarPuerta();
        miCoche.mostrar();
    }

    public static void suma(int a, int b,int c){
        int resultado= a+b+c;
        System.out.println(resultado);
    }
}

class Coche{
    private int puertas=0;

    public void agregarPuerta(){
        this.puertas++;
    }
    public void mostrar(){
        System.out.println(this.puertas);
    }

}